function [S_eta, relax]=FormConstraintAll(eta,varargin)
    if size(varargin)>0
        Y=varargin{1};
        ratio=varargin{2};
    end
    eta=eta|eta';
    eta=eta-diag(diag(eta));
    eta=triu(eta);
    
    N_eta=sum(eta(:));
    [idxx idxy]=ind2sub(size(eta),find(eta(:)));
    temp=sparse(1:length(idxx),idxx,ones(size(idxx)),N_eta, size(eta,1));
    S_eta=temp+sparse(1:length(idxy),idxy,-ones(size(idxy)),N_eta, size(eta,1));
    
    relax=[];
%     temp=S_eta*Y;
%     relax=ones(size(temp));
%     relax(temp~=0,:)=1+ratio;
return;