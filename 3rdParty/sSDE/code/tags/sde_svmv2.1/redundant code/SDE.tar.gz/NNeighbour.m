% LLE ALGORITHM
%
% function [Y,eigenvals,neighbors] = lle(X,K,d,tol)
%
% X = data as D x N matrix (D = dimensionality, N = #points)
% K = number of neighbors
% d = embedding dimensionality
% tol = regularizer (defaults to 1e-4)
% Y = embedding as d x N matrix
% WW(i,j)=1 means ith  is the neighbour of jth
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function WW = NNeighbour(X,K, varargin)

% PAIRWISE DISTANCES
[D,N] = size(X);
WW=zeros(N,N);
optargin = size(varargin,2);
if optargin>1
    display('too many input arguments');
    return;
end
X2 = sum(X.^2,1);
distance = repmat(X2,N,1)+repmat(X2',1,N)-2*X'*X;

% NEIGHBORS
for i=1:N
    distance(i,i)=max(distance(i,:));
end
[sorted,index] = sort(distance);
neighborhood=cell(1,N);
tol=1e-4;
for i=1:N
    KK=K;
    if optargin==1 && sorted(KK,i)>varargin{1}
        KK=sum(double(sorted(:,i)<=varargin{1}));
    end
    neighbors{i} = index(1:KK,i);
    WW(neighbors{i},i)= 1;
end;
% WW(2:end,1:end-1)=WW(2:end,1:end-1)+eye(N-1);

return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
